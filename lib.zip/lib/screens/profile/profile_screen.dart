import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Giả lập trạng thái đăng nhập
  bool isLoggedIn = true;

  // Giả lập thông tin user (bạn thay bằng dữ liệu thực tế)
  final String userName = "Nguyễn Văn A";
  final String userEmail = "nguyenvana@gmail.com";
  final String userPhone = "0912345678";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tài khoản'),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.5,
      ),
      body: isLoggedIn ? _buildLoggedInView() : _buildNotLoggedInView(),
    );
  }

  Widget _buildNotLoggedInView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircleAvatar(
              radius: 46,
              child: Icon(Icons.person, size: 46),
            ),
            const SizedBox(height: 24),
            const Text(
              "Bạn chưa đăng nhập",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
            const SizedBox(height: 14),
            const Text(
              "Vui lòng đăng nhập để sử dụng đầy đủ các chức năng quản lý vé và thông tin cá nhân.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, color: Colors.grey),
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // Chuyển sang trang đăng nhập
                  context.go('/login');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text(
                  "Đăng nhập / Đăng ký",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildLoggedInView() {
    return ListView(
      children: [
        const SizedBox(height: 24),
        Center(
          child: Column(
            children: [
              const CircleAvatar(
                radius: 46,
                child: Icon(Icons.person, size: 46),
              ),
              const SizedBox(height: 12),
              Text(
                userName,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
              ),
              const SizedBox(height: 4),
              Text(userPhone, style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 2),
              Text(userEmail, style: const TextStyle(color: Colors.black54)),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.person_outline, color: Colors.green),
          title: const Text('Hồ sơ cá nhân'),
          onTap: () {
            // Điều hướng sang màn cập nhật thông tin cá nhân
            context.push('/profile/edit');
          },
        ),
        ListTile(
          leading: const Icon(Icons.history, color: Colors.blue),
          title: const Text('Lịch sử đặt vé'),
          onTap: () {
            // Điều hướng sang màn lịch sử đặt vé
            context.push('/my_tickets');
          },
        ),
        ListTile(
          leading: const Icon(Icons.support_agent, color: Colors.orange),
          title: const Text('Hỗ trợ khách hàng'),
          onTap: () {
            // Điều hướng sang hỗ trợ khách hàng
            context.push('/support');
          },
        ),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: const Text('Đăng xuất'),
          onTap: () {
            // Xử lý đăng xuất
            setState(() {
              isLoggedIn = false;
            });
            // Thông báo đăng xuất thành công (nếu muốn)
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Bạn đã đăng xuất")),
            );
          },
        ),
      ],
    );
  }
}
