import 'package:flutter/material.dart';

class OffersScreen extends StatelessWidget {
  const OffersScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Ví dụ danh sách khuyến mãi/ưu đãi giả lập
    final List<Offer> offers = [
      Offer(
        title: 'Giảm 10% cho chuyến đầu tiên!',
        code: 'NEW10',
        description: 'Chỉ áp dụng cho khách hàng mới đặt chuyến đầu tiên trên ứng dụng.',
        expired: 'HSD: 31/07/2025',
      ),
      Offer(
        title: 'Mã giảm 20K cho đơn từ 200K',
        code: 'SUMMER20K',
        description: 'Đặt vé từ 200.000đ trở lên, nhập mã giảm ngay 20.000đ.',
        expired: 'HSD: 15/08/2025',
      ),
      Offer(
        title: 'Ưu đãi thanh toán MoMo',
        code: 'MOMO10',
        description: 'Giảm 10.000đ khi thanh toán qua ví MoMo.',
        expired: 'HSD: 30/09/2025',
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ưu đãi & Khuyến mãi'),
        centerTitle: true,
        backgroundColor: Colors.green,
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: offers.length,
        separatorBuilder: (_, __) => const SizedBox(height: 16),
        itemBuilder: (context, index) {
          final offer = offers[index];
          return OfferCard(offer: offer);
        },
      ),
    );
  }
}

class Offer {
  final String title;
  final String code;
  final String description;
  final String expired;

  Offer({
    required this.title,
    required this.code,
    required this.description,
    required this.expired,
  });
}

class OfferCard extends StatelessWidget {
  final Offer offer;

  const OfferCard({Key? key, required this.offer}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              offer.title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    offer.code,
                    style: const TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                      fontSize: 16,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  offer.expired,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              offer.description,
              style: const TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: () {
                  // TODO: Copy mã khuyến mãi, hoặc áp dụng mã
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Đã sao chép mã: ${offer.code}')),
                  );
                },
                icon: const Icon(Icons.copy, size: 18),
                label: const Text('Sao chép mã'),
                style: TextButton.styleFrom(
                  foregroundColor: Colors.green,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
