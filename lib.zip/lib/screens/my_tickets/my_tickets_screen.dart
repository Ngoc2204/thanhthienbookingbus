import 'package:flutter/material.dart';

class MyTicketsScreen extends StatelessWidget {
  const MyTicketsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Giả lập danh sách vé đã đặt
    final List<Ticket> tickets = [
      Ticket(
        route: 'Chu Lai → Đà Nẵng',
        time: '08:00, 25/07/2025',
        seat: 'A12',
        code: 'TTX123456',
        status: 'Đã thanh toán',
      ),
      Ticket(
        route: 'Chu Lai → Tam Kỳ',
        time: '16:00, 28/07/2025',
        seat: 'B03',
        code: 'TTX654321',
        status: 'Chưa thanh toán',
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Vé của tôi'),
        centerTitle: true,
        backgroundColor: Colors.green,
      ),
      body: tickets.isEmpty
          ? const Center(
        child: Text(
          'Bạn chưa có vé nào.',
          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
      )
          : ListView.separated(
        padding: const EdgeInsets.all(20),
        itemCount: tickets.length,
        separatorBuilder: (_, __) => const SizedBox(height: 16),
        itemBuilder: (context, index) {
          final ticket = tickets[index];
          return TicketCard(ticket: ticket);
        },
      ),
    );
  }
}

class Ticket {
  final String route;
  final String time;
  final String seat;
  final String code;
  final String status;

  Ticket({
    required this.route,
    required this.time,
    required this.seat,
    required this.code,
    required this.status,
  });
}

class TicketCard extends StatelessWidget {
  final Ticket ticket;

  const TicketCard({Key? key, required this.ticket}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color statusColor =
    ticket.status == 'Đã thanh toán' ? Colors.green : Colors.orange;
    IconData statusIcon =
    ticket.status == 'Đã thanh toán' ? Icons.check_circle : Icons.access_time;

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 3,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          // TODO: Điều hướng tới chi tiết vé hoặc hiện QR code
          showModalBottomSheet(
            context: context,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            builder: (context) => TicketDetailSheet(ticket: ticket),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                ticket.route,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.schedule, size: 18, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text(ticket.time),
                  const Spacer(),
                  Chip(
                    label: Text(
                      ticket.status,
                      style: const TextStyle(color: Colors.white),
                    ),
                    backgroundColor: statusColor,
                    avatar: Icon(statusIcon, color: Colors.white, size: 18),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.event_seat, size: 18, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text('Ghế: ${ticket.seat}'),
                  const SizedBox(width: 20),
                  const Icon(Icons.confirmation_number, size: 18, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text('Mã vé: ${ticket.code}'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Widget hiển thị chi tiết vé khi bấm vào vé (bottom sheet)
class TicketDetailSheet extends StatelessWidget {
  final Ticket ticket;

  const TicketDetailSheet({Key? key, required this.ticket}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: Tích hợp mã QR thực tế (hiện tạm mã vé)
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Thông tin vé',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.confirmation_number, color: Colors.green),
              const SizedBox(width: 8),
              Text(
                ticket.code,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Tuyến:', style: TextStyle(fontWeight: FontWeight.w500)),
              Text(ticket.route),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Thời gian:', style: TextStyle(fontWeight: FontWeight.w500)),
              Text(ticket.time),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Ghế:', style: TextStyle(fontWeight: FontWeight.w500)),
              Text(ticket.seat),
            ],
          ),
          const SizedBox(height: 24),
          // Mã QR (ở đây tạm thay bằng code, bạn có thể tích hợp thư viện QR Flutter)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.green, width: 2),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                const Icon(Icons.qr_code, size: 60, color: Colors.green),
                const SizedBox(height: 12),
                Text(
                  ticket.code,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text('Quét mã này để lên xe', style: TextStyle(color: Colors.grey[600])),
              ],
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.copy),
              label: const Text('Sao chép mã vé'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              onPressed: () {
                // TODO: Copy code vé vào clipboard
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Đã sao chép mã: ${ticket.code}')),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
