import 'package:flutter/material.dart';

import '../payment/payment_screen.dart';

class BookingScreen extends StatefulWidget {
  final String route;
  final String time;
  final String price;

  const BookingScreen({
    Key? key,
    required this.route,
    required this.time,
    required this.price,
  }) : super(key: key);

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  String? selectedSeat;
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final emailController = TextEditingController();

  final List<String> availableSeats = [
    'A1', 'A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Đặt vé'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            Text(widget.route, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('Giờ xuất phát: ${widget.time}', style: const TextStyle(fontSize: 16)),
            Text('Giá: ${widget.price}', style: const TextStyle(fontSize: 16, color: Colors.green)),
            const SizedBox(height: 20),

            const Text('Chọn ghế:', style: TextStyle(fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 8,
              children: availableSeats.map((seat) {
                final isSelected = selectedSeat == seat;
                return ChoiceChip(
                  label: Text(seat),
                  selected: isSelected,
                  onSelected: (_) {
                    setState(() {
                      selectedSeat = seat;
                    });
                  },
                  selectedColor: Colors.green,
                );
              }).toList(),
            ),
            const SizedBox(height: 20),

            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Họ và tên', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: phoneController,
              decoration: const InputDecoration(labelText: 'Số điện thoại', border: OutlineInputBorder()),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder()),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 20),

            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: () {
                  if (selectedSeat == null ||
                      nameController.text.trim().isEmpty ||
                      phoneController.text.trim().isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Vui lòng chọn ghế và nhập đầy đủ thông tin')),
                    );
                    return;
                  }
                  // Chuyển sang trang thanh toán, truyền thông tin
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PaymentScreen(
                        title: 'Đặt vé thành công',
                        detail: '${widget.route}\nGhế: $selectedSeat\nGiá: ${widget.price}',
                      ),
                    ),
                  );
                },
                child: const Text('Đặt vé', style: TextStyle(fontSize: 18)),
              ),
            )
          ],
        ),
      ),
    );
  }
}
