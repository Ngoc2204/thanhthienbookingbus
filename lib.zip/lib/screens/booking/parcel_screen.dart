import 'package:flutter/material.dart';

import '../payment/payment_screen.dart';

class ParcelScreen extends StatefulWidget {
  const ParcelScreen({Key? key}) : super(key: key);

  @override
  State<ParcelScreen> createState() => _ParcelScreenState();
}

class _ParcelScreenState extends State<ParcelScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController senderNameController = TextEditingController();
  final TextEditingController senderPhoneController = TextEditingController();
  final TextEditingController receiverNameController = TextEditingController();
  final TextEditingController receiverPhoneController = TextEditingController();
  final TextEditingController itemInfoController = TextEditingController();

  String? pickUpMethod;
  final List<String> pickUpOptions = [
    'Giao tại bến xe',
    'Nhận tận nơi (phụ thu)',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gửi hàng'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Thông tin người gửi',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: senderNameController,
                decoration: const InputDecoration(
                  labelText: 'Họ tên người gửi',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Nhập tên người gửi' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: senderPhoneController,
                decoration: const InputDecoration(
                  labelText: 'SĐT người gửi',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
                validator: (value) => value == null || value.isEmpty ? 'Nhập SĐT người gửi' : null,
              ),
              const SizedBox(height: 18),
              const Text(
                'Thông tin người nhận',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: receiverNameController,
                decoration: const InputDecoration(
                  labelText: 'Họ tên người nhận',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Nhập tên người nhận' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: receiverPhoneController,
                decoration: const InputDecoration(
                  labelText: 'SĐT người nhận',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
                validator: (value) => value == null || value.isEmpty ? 'Nhập SĐT người nhận' : null,
              ),
              const SizedBox(height: 18),
              const Text(
                'Thông tin kiện hàng',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: itemInfoController,
                decoration: const InputDecoration(
                  labelText: 'Nội dung/Loại hàng (vd: Quần áo, Bưu phẩm...)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Nhập nội dung hàng' : null,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: pickUpMethod,
                decoration: const InputDecoration(
                  labelText: 'Hình thức nhận/giao hàng',
                  border: OutlineInputBorder(),
                ),
                items: pickUpOptions
                    .map((option) => DropdownMenuItem(
                  value: option,
                  child: Text(option),
                ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    pickUpMethod = value;
                  });
                },
                validator: (value) => value == null || value.isEmpty ? 'Chọn hình thức nhận/giao' : null,
              ),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      // Chuyển sang trang thanh toán, truyền thông tin
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PaymentScreen(
                            title: 'Gửi hàng thành công',
                            detail: 'Gửi: ${senderNameController.text} - ĐT: ${senderPhoneController.text}\n'
                                'Nhận: ${receiverNameController.text} - ĐT: ${receiverPhoneController.text}\n'
                                'Loại hàng: ${itemInfoController.text}',
                          ),
                        ),
                      );
                    }
                  },
                  icon: const Icon(Icons.send),
                  label: const Text(
                    'Gửi yêu cầu',
                    style: TextStyle(fontSize: 17),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
