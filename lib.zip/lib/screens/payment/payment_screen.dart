import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class PaymentScreen extends StatelessWidget {
  final String title; // Đặt vé/Gửi hàng
  final String detail; // Tuyến, giá, hoặc nội dung gửi hàng

  const PaymentScreen({Key? key, required this.title, required this.detail}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String selectedMethod = 'cash';

    return StatefulBuilder(
      builder: (context, setState) => Scaffold(
        appBar: AppBar(
          title: const Text('Thanh toán'),
          backgroundColor: Colors.green,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              const SizedBox(height: 12),
              Text(detail, style: const TextStyle(fontSize: 16, color: Colors.black87)),
              const Divider(height: 32),
              const Text('Chọn phương thức thanh toán:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
              const SizedBox(height: 12),
              RadioListTile<String>(
                value: 'online',
                groupValue: selectedMethod,
                onChanged: (val) => setState(() => selectedMethod = val!),
                title: const Text('Thanh toán trực tuyến'),
              ),
              if (selectedMethod == 'online')
                Padding(
                  padding: const EdgeInsets.only(left: 24),
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.credit_card, color: Colors.blue),
                        title: const Text('ATM/Internet Banking'),
                        onTap: () {},
                      ),
                      ListTile(
                        leading: const Icon(Icons.qr_code_2, color: Colors.green),
                        title: const Text('Quét mã QR ngân hàng'),
                        onTap: () {},
                      ),
                      ListTile(
                        leading: const Icon(Icons.phone_android, color: Colors.orange),
                        title: const Text('Ví MoMo'),
                        onTap: () {},
                      ),
                      ListTile(
                        leading: const Icon(Icons.account_balance_wallet, color: Colors.blueAccent),
                        title: const Text('Ví ZaloPay'),
                        onTap: () {},
                      ),
                    ],
                  ),
                ),
              RadioListTile<String>(
                value: 'cash',
                groupValue: selectedMethod,
                onChanged: (val) => setState(() => selectedMethod = val!),
                title: const Text('Thanh toán tiền mặt khi nhận vé/gửi hàng'),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Thanh toán thành công!'),
                        content: Text(
                          selectedMethod == 'cash'
                              ? 'Bạn đã chọn thanh toán khi nhận vé/gửi hàng.'
                              : 'Bạn đã thanh toán trực tuyến thành công (demo).',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                              context.go('/my_tickets');
                            },
                            child: const Text('OK', style: TextStyle(color: Colors.green)),
                          ),
                        ],
                      ),
                    );
                  },
                  child: const Text('Thanh toán', style: TextStyle(fontSize: 18)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
