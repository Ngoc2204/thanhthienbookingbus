import 'package:flutter/material.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hỗ trợ khách hàng'),
        centerTitle: true,
        backgroundColor: Colors.green,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Phần 1: Câu hỏi thường gặp (FAQ)
          const Text(
            'Câu hỏi thường gặp',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          _FaqItem(
            question: 'Làm sao để đặt vé?',
            answer: 'Bạn chỉ cần nhập điểm đi, điểm đến và ngày đi ở trang chủ, sau đó chọn chuyến xe phù hợp và làm theo hướng dẫn.',
          ),
          _FaqItem(
            question: 'Thanh toán như thế nào?',
            answer: 'Bạn có thể thanh toán qua VNPay, MoMo hoặc chuyển khoản ngân hàng trực tiếp trên ứng dụng.',
          ),
          _FaqItem(
            question: 'Tôi muốn huỷ vé phải làm sao?',
            answer: 'Vào mục "Vé của tôi" chọn vé cần huỷ và làm theo hướng dẫn. Lưu ý điều kiện hoàn vé theo chính sách nhà xe.',
          ),
          _FaqItem(
            question: 'Làm sao để gửi hàng hóa?',
            answer: 'Bạn có thể chọn tính năng "Gửi hàng" trên trang chủ hoặc liên hệ hotline để được hỗ trợ nhanh nhất.',
          ),
          const SizedBox(height: 24),

          // Phần 2: Các kênh liên hệ
          const Text(
            'Liên hệ trực tiếp',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ListTile(
            leading: const Icon(Icons.phone, color: Colors.green),
            title: const Text('Hotline'),
            subtitle: const Text('1900 1234'),
            onTap: () {
              // TODO: Tích hợp gọi điện
            },
          ),
          ListTile(
            leading: const Icon(Icons.email_outlined, color: Colors.red),
            title: const Text('Email hỗ trợ'),
            subtitle: const Text('hotro@thanthienbus.vn'),
            onTap: () {
              // TODO: Mở ứng dụng gửi mail
            },
          ),
          ListTile(
            leading: const Icon(Icons.facebook, color: Colors.blue),
            title: const Text('Facebook Fanpage'),
            subtitle: const Text('fb.com/thanthienbus'),
            onTap: () {
              // TODO: Mở link Facebook
            },
          ),
          ListTile(
            leading: const Icon(Icons.chat_bubble_outline, color: Colors.teal),
            title: const Text('Zalo Hỗ trợ'),
            subtitle: const Text('Zalo OA: 0901122333'),
            onTap: () {
              // TODO: Mở link Zalo
            },
          ),
          const SizedBox(height: 32),

          // Phần 3: Gửi phản hồi
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            icon: const Icon(Icons.feedback_outlined),
            label: const Text(
              'Gửi phản hồi / yêu cầu hỗ trợ',
              style: TextStyle(fontSize: 16),
            ),
            onPressed: () {
              // TODO: Điều hướng tới form gửi phản hồi hoặc mở bottom sheet nhập ý kiến
            },
          ),
        ],
      ),
    );
  }
}

// Widget cho từng mục FAQ (có thể bấm để xem chi tiết nếu cần)
class _FaqItem extends StatelessWidget {
  final String question;
  final String answer;

  const _FaqItem({
    Key? key,
    required this.question,
    required this.answer,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      title: Text(question, style: const TextStyle(fontWeight: FontWeight.w500)),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8),
          child: Text(answer),
        ),
      ],
    );
  }
}
